package csye6220.assignment6.dao;

import csye6220.assignment6.account.account;

public interface accountDao {

	public void add(account account);

}
